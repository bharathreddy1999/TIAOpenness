﻿// A little index list for table for easier shuffling of header and TD s - used to map icons also
const processStationIndexes = {
    Workstation: 0,
    Available: 1,
    Blocked: 2,
    Reserved: 3,
    Occupied: 4,
    BodyID: 5,
    Arrived: 6,
    Target: 7,
    TransportOrder: 8
}

// A mapping object for icons for easy changing
const processStationIconMap = {
    Available: {
        true: '<img src="./images/worker.svg">',
        false: '<p>-</p>'
    },
    Blocked: {
        true: '<img src="./images/status_blocked.svg">',
        false: '<p>-</p>'
    },
    Reserved: {
        true: '<img src="./images/status_reserved.svg">',
        false: '<p>-</p>'
    },
    Occupied: {
        true: '<img src="./images/car_body.svg">',
        false: '<p>-</p>',
        occupied: '<img src="./images/occupied_wrench.svg">',
        ready: '<img src="./images/occupied_check.svg">',
        empty: '<p>-</p>'
    }
}

const transferStationsIndexes = {
    TransferStation: 0,
    Blocked: 1,
    Occupied: 2,
    BodyID: 3,
    Target: 4,
    TransportOrder: 5
}

const buffersIndexes = {
    BufferStation: 0,
    Blocked: 1,
    Reserved: 2,
    Occupied: 3,
    BodyID: 4,
    Arrived: 5,
    Target: 6,
    TransportOrder: 7,
}

//initialization
var currentView = "processStations";
var queuePage = 1;
var elementsPerPage = 5;
var totalPages = 1;
var openQueueProcessStation = "";
var filter = "Select"
setInterval(getDataAndUpdateView, 2000);
getDataAndUpdateView();

function getDataAndUpdateView() {
    updateConnectionStatus();
    if (currentView == "processStations")
        getDataAndUpdateStationsWithHeaders("processstationsstatus",
            "processStationsList");
    if (currentView == "transferStations")
        getDataAndUpdateTable("transferstationsstatus",
            "transferStationsList");
    if (currentView == "buffers")
        getDataAndUpdateStationsWithHeaders("buffersstatus", "buffersList");
}

function updateConnectionStatus() {
    $.get("connectionstatus", function(data) {
        var obj = jQuery.parseJSON(data);
        document.getElementById("connectionPLC").src = (obj.PLC) ?
            'images/connectionOn.svg' : 'images/connectionOff.svg';
        document.getElementById("connectionFleetManager").src = (obj.FleetManager) ?
            'images/connectionOn.svg' : 'images/connectionOff.svg';
        document.getElementById("connectionMFC").src =
            'images/connectionOn.svg';
    }).fail(function(jqXHR, textStatus, errorThrown) {
        document.getElementById("connectionMFC").src =
            'images/connectionOff.svg';
    });
}

function getDataAndUpdateTable(url, tableId) //for buffer
{
    $.get(url, function(data) {
        var obj = jQuery.parseJSON(data);
        var tbody = document.getElementById(tableId).getElementsByTagName(
            "tbody")[0];
        //update table content
        deleteTableRows(tbody);
        for (var i = 0; i < obj.data.length; i++) {
            var row = createDataRow(obj.data[i], transferStationsIndexes,
                processStationIconMap);
            tbody.insertAdjacentElement("beforeend", row);
        }
    }).fail(function(jqXHR, textStatus, errorThrown) {
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
}

function deleteTableRows(tbody) {
    var rows = tbody.getElementsByTagName('tr');
    for (var i = 0; i < rows.length; i++) {
        if (!rows[i].id) {
            tbody.removeChild(rows[i]);
            i--;
        }
    }
}

function getDataAndUpdateStationsWithHeaders(url, tableId) {
    $.get(url, function(data) {
        var obj = jQuery.parseJSON(data);
        var list = document.getElementById(tableId);
        var colspan;
        var queue = true;
        if (tableId == "processStationsList") {
            colspan = 9;
        }
        else if (tableId == "buffersList") {
            colspan = 8;
            queue = false;
        }
        //Check subheaders with stations and add if necessary , add queue divs
        for (var i = 0; i < obj.data.length; i++) {
            var station = document.getElementById(obj.data[i].name);
            if (station == null)
            {
                addProcessStation(list, obj.data[i], colspan);
            }
            var tab = document.getElementById(obj.data[i].name + "Queue");
            if (tab == null) {
                var queueDiv = document.getElementById("queueBody");
                var tabid = document.createElement("div");
                tabid.className = "queueTab";
                tabid.id = obj.data[i].name + "Queue";
                queueDiv.append(tabid);
            }
            addFilterOption(obj.data[i])
        }
        //delete content of subheaders to update
        deleteTableRows(document.getElementById(tableId).getElementsByTagName(
            "tbody")[0]);
        deleteQueueRows()
            //insert new content
        for (let i = 0; i < obj.data.length; i++) {
            var indexes;
            var stations;
            var name = obj.data[i].name;
            if (tableId == "processStationsList") {
                indexes = processStationIndexes;
                stations = obj.data[i].workstations;
            }
            else if (tableId == "buffersList") {
                indexes = buffersIndexes;
                stations = obj.data[i].bufferstations;
            }
            if (i < data.length - 1) {
                //Find next subheader to add before it. 
                var tr = document.getElementById(name);
                for (let j = stations.length - 1; j >= 0; j--) {
                    var element = createDataRow(stations[j], indexes,
                        processStationIconMap, queue);
                    tr.insertAdjacentElement("afterend", element); //insert just before next subheader
                }
            }
            else //insert for last subheader - at end of tbody. 
            {
                list.getElementsByTagName('tbody')[0]; //tbody of table
                for (let j = obj.data[i].workstations.length - 1; j >= 0; j--) {
                    var element = createDataRow(stations[j], indexes,
                        processStationIconMap, queue);
                    list.insertAdjacentElement(beforeend, element); //insert at end of tbody
                }
            }
            //queue
            if (obj.data[i].queue) {
                updateQueueLengthDisplay(obj.data[i].queue, name);
                createQueueElement(obj.data[i].queue, name);
            }
        }
		updateQueuePaging();
		displayQueueElements();
		selectOption(filter);
    });
}

function addFilterOption(station) {
    var options;
    if (currentView == "processStations")
        options = document.getElementById("processoptions")
    else if (currentView == "buffers")
        options = document.getElementById("bufferoptions")
    var liList = options.querySelectorAll('li');
    var found = false;
    liList.forEach(function (li) {
        if (li.innerText == station.name)
            found = true;
    })
    if (found) {
        return;
    }
    var item = document.createElement("li")
    item.onclick = function(){selectOption(this.textContent)};
    item.textContent = station.name;
    options.appendChild(item)
}

function deleteQueueRows() {
    var queue = document.getElementsByClassName("queueTab")
    for (let j = 0; j < queue.length; j++) {
        while (queue[j].firstChild) {
            queue[j].firstChild.remove()
        }
    }
}

function updateQueueLengthDisplay(queueData, processStationName) {
    var stationTr = document.getElementById(processStationName);
    var p = stationTr.getElementsByTagName("p")[0];
    p.innerText = queueData.length;
}

function updateQueuePaging() {
	if (openQueueProcessStation != "") {
		var queueTab = document.getElementById(openQueueProcessStation + "Queue");
		var queueElements = queueTab.querySelectorAll(".queueElement");
		var totalElements = queueElements.length;
		totalPages = Math.ceil(totalElements / elementsPerPage);
		if (queuePage > totalPages)
			queuePage = totalPages;
		if (queuePage < 1)
			queuePage = 1;
	}
}

function createQueueElement(data, queueName) {
    var queueDiv = document.getElementById("queueBody");
    for (let j = 0; j < data.length; j++) {
        var tabid = document.getElementById(queueName + "Queue")
        var queueElement = document.createElement("div");
        queueElement.className = "queueElement";
        tabid.append(queueElement);
        var queueBodyHeader = document.createElement("div");
        queueBodyHeader.className = "queueElementHeader";
        queueElement.append(queueBodyHeader);
        var icon = document.createElement("img");
        icon.src = "images/car_body.svg";
        queueBodyHeader.append(icon);
        var id = document.createElement("p");
        id.innerText = data[j][2];
        queueBodyHeader.append(id);
        var div1 = document.createElement("div");
        div1.className = "queueElementBody";
        queueElement.append(div1);
        var p1 = document.createElement("p");
        p1.innerText = "Source";
        div1.append(p1);
        var p2 = document.createElement("p");
        p2.innerText = data[j][0];
        div1.append(p2);
        var div2 = document.createElement("div");
        div2.className = "queueElementBody";
        queueElement.append(div2);
        var p1 = document.createElement("p");
        p1.innerText = "Waiting location";
        div2.append(p1);
        var p2 = document.createElement("p");
        p2.innerText = data[j][1];
        div2.append(p2);
        var div3 = document.createElement("div");
        div3.className = "queueElementBody";
        queueElement.append(div3);
        var p1 = document.createElement("p");
        p1.innerText = "Waiting since";
        div3.append(p1);
        var p2 = document.createElement("p");
        p2.innerText = data[j][3];
        div3.append(p2);
    }
}

function createDataRow(data, dataIndexes, iconMap, queue) {
    var tr = document.createElement("tr");
    //Work Station
    Object.keys(dataIndexes).forEach(function(key) {
        var td = document.createElement("td");
        if (iconMap[key] !== undefined) {
            td.className = "icon";
            for (let subkey in iconMap[key]) {
                var test = data[dataIndexes[key]].toString()
                if (subkey == test) {
                    td.innerHTML = iconMap[key][subkey];
                }
            }
        }
        else {
            if (data[dataIndexes[key]] === undefined)
                td.InnerText = "";
            else
                td.innerText = data[dataIndexes[key]];
        }
        tr.appendChild(td);
    })
    if (queue === true) {
        tr.appendChild(document.createElement("td")); //add to fill gap below waiting queue button and retain styles
    }
    return tr;
}

function addProcessStation(list, station, colspan) {
    //get table body
    var body = list.getElementsByTagName('tbody')[0];
    //add subheader row
    var entry = document.createElement("tr");
    entry.id = station.name;
    entry.className = "processStation border-t3";
    body.appendChild(entry);
    //add station subheader and button
    var header = document.createElement("td");
    header.colSpan = colspan;
    header.className = "stationHeader";
    header.innerText = station.name;
    entry.appendChild(header);
    //queue cell with/without button
    if (station.queue) {
        var queueCell = document.createElement("td");
        queueCell.className = "stationHeader icon";
        var icon = document.createElement("img");
        icon.src = "./images/car_body.svg";
        var p = document.createElement("p");
        p.innerText = "";
        p.classList.add("queueLength");
        var button = document.createElement("button");
        button.className = "button-secondary button-small";
        button.onclick = function () {
            openWaitingQueue(button)
        }
        button.appendChild(icon);
        button.appendChild(p);
        queueCell.appendChild(button);
        entry.appendChild(queueCell);
    }
}

function addHeadlineToTable(thead, width, name) {
    var entry = document.createElement("th");
    entry.width = width;
    entry.innerText = name;
    thead.appendChild(entry);
}

function changeTab(event, content) {
    if (content == "processStations") {
        $("#processStationsTab").addClass("active");
        $("#transferStationsTab").removeClass("active");
        $("#buffersTab").removeClass("active");
        $("#processStations").addClass("active");
        $("#transferStations").removeClass("active");
        $("#buffers").removeClass("active");
        $("#processStationsButtons").addClass("active")
        $("#transferStationsButtons").removeClass("active")
        $("#buffersButtons").removeClass("active")
        $("#bufferfilter").removeClass("active")
        $("#transferfilter").removeClass("active")
        $("#processfilter").addClass("active")
        currentView = "processStations";
        filter = "Select"
    }
    else if (content == "transferStations") {
        $("#processStationsTab").removeClass("active");
        $("#transferStationsTab").addClass("active");
        $("#buffersTab").removeClass("active");
        $("#processStations").removeClass("active");
        $("#transferStations").addClass("active");
        $("#buffers").removeClass("active");
        $("#processStationsButtons").removeClass("active")
        $("#transferStationsButtons").addClass("active")
        $("#buffersButtons").removeClass("active")
        $("#bufferfilter").removeClass("active")
        $("#processfilter").removeClass("active")
        $("#transferfilter").addClass("active")
        currentView = "transferStations";
        closeWaitingQueue();
    }
    else {
        $("#processStationsTab").removeClass("active");
        $("#transferStationsTab").removeClass("active");
        $("#buffersTab").addClass("active");
        $("#processStations").removeClass("active");
        $("#transferStations").removeClass("active");
        $("#buffers").addClass("active");
        $("#processStationsButtons").removeClass("active")
        $("#transferStationsButtons").removeClass("active")
        $("#buffersButtons").addClass("active")
        $("#processfilter").removeClass("active")
        $("#transferfilter").removeClass("active")
        $("#bufferfilter").addClass("active")
        currentView = "buffers";
        closeWaitingQueue();
        filter = "Select"
    }
    getDataAndUpdateView();
}

//Custom select for plant status
function toggleOptions() {
    if(currentView == "buffers")
        var options = document.getElementsByClassName("options")[1]
    else
        var options = document.querySelector('.options');
    options.style.display = options.style.display === 'none' ? 'block' :
        'none';
}

//Hide Options of select when pressed outside of select div
document.addEventListener('click', function (event) {
    var customSelect = document.querySelector('.custom-select');
    if (event.target !== customSelect && !customSelect.contains(event.target)) {
        var options = customSelect.querySelector('.options');
        options.style.display = 'none';
    }
});
 
function selectOption(option) {
    var value = option;
    if(currentView === "processStations")
    {
        document.querySelector('.custom-select input').value = value;
        document.querySelector('.options').style.display = 'hidden';
    }
    else
    {
        document.querySelectorAll('.custom-select input')[1].value = value;
         document.querySelectorAll('.options')[1].style.display = 'hidden';
    }
    filter = value;
    //filter table
    if(value !== "Select") //Select for selecting all, can be changed here in future if needed
    {
        document.getElementById(currentView+"Body").childNodes.forEach(node =>
        {
            if(node.nodeName === 'TR')
                node.style.display = "none"
        })      
        var start = document.getElementById(value);
        if (start)
        {
            start.style.display ="";
            var next = start.nextElementSibling;
            if(next.hasAttribute('id'))
                return;
            while(next && next.tagName === 'TR' && !next.hasAttribute('id'))
            {
                next.style.display = "";
                next = next.nextElementSibling
            }
        }
    }
    else
    {
        document.getElementById(currentView+"Body").childNodes.forEach(node =>
            {
                if(node.nodeName === 'TR')
                    node.style.display = ""
            })  
    }
}

function resetFilter() {
    selectOption("Select");
}

function openWaitingQueue(tabName) {
    //check if this queue is already opened, then close queue window
    if (tabName.classList.contains("pressed")) {
        closeWaitingQueue();
		openQueueProcessStation = "";
        return;
    }

    //open queue window/change queue
    removePressedClass()
    tabName.classList.add("pressed")
    var name = tabName.parentNode.parentNode.id;
    console.log(name);
    var tab = document.getElementsByClassName('waitingQueue')[0];
    tab.style = "display:absolute";
    var tabs = document.getElementsByClassName('queueTab');
    for (let i = 0; i < tabs.length; i++) {
        tabs[i].style = "display:none";
    }
    var queueTab = document.getElementById(name + "Queue");
    if (queueTab) {
        queueTab.style.display = "block";
        var queueElements = queueTab.querySelectorAll(".queueElement");
        // Pagination logic
        var totalElements = queueElements.length;
        totalPages = Math.ceil(totalElements / elementsPerPage);
        queuePage = 1;
		openQueueProcessStation = name;
        displayQueueElements()
    }
}

function displayQueueElements() {
	if (openQueueProcessStation != "") {
		var start = (queuePage - 1) * elementsPerPage;
		var end = start + elementsPerPage;
		var queueTab = document.getElementById(openQueueProcessStation + "Queue");
		var queueElements = queueTab.querySelectorAll(".queueElement");
		// Hide all elements
		queueElements.forEach(function(element) {
			element.style.display = 'none';
		});
		// Display elements for the current page
		for (var i = start; i < end && i < queueElements.length; i++) {
			queueElements[i].style.display = 'block';
		}

		// Update amout of queue entries in headline
        var headline = document.getElementById("waitingQueueHeadline");
        headline.innerText = "Waiting queue | " + queueElements.length;
	}
}

function previousPage() {
    if (queuePage > 1) {
        queuePage--;
        displayQueueElements();
    }
}

function nextPage() {
    if (queuePage < totalPages) {
        queuePage++;
        displayQueueElements();
    }
}

function closeWaitingQueue() {
    removePressedClass()
    var tab = document.getElementsByClassName('waitingQueue')[0];
    tab.style = "display:none";
}

function scrollTable(direction, element) {
    var tableContainer = document.getElementById(element);
    var scrollStep = 100;
    if (direction === 'up') {
        tableContainer.scrollTop -= scrollStep;
    }
    else if (direction === 'down') {
        tableContainer.scrollTop += scrollStep;
    }
}

function removePressedClass() {
    var items = document.getElementsByClassName("pressed")
    for (var i = 0; i < items.length; i++) {
        items[i].classList.remove("pressed")
    }
}