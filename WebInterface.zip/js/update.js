﻿//send rest request every 1s and update view
setInterval(getDataAndUpdateView, 1000);
getDataAndUpdateView();

function getDataAndUpdateView() {
    $.get("getdata", function (data) {
        var obj = jQuery.parseJSON(data);
        $("#title").html("Dürr EcoProFleet - Material Flow Control(MFC) " + obj.AppVersion);
        $("#AppVersion").text(obj.AppVersion);
        $("#ServerConnectionStatus").text(obj.ServerConnectionStatus);
        $("#ServerUrl").text(obj.ServerUrl);
        $("#ServerVersion").text(obj.ServerVersion);
        $("#LabVersion").text(obj.LabVersion);
        $("#ProjectName").text(obj.ProjectName);
        $("#copyright").html("&copy; 2020 Dürr Systems AG<br />" + obj.DateTime);
    });
}
