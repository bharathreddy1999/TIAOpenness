﻿const dataIndexes ={
    OrderID         : 0,
    BodyID          : 1,
    Source          : 2,
    Target          : 3,
    CreationTime    : 4,
    PickupTime      : 5,
    DeliveryTime    : 6,
    AGV             : 7,
    Status          : 8,
    Delete          : 9
}
//initialization
var currentView = "current";

addSourcesAndTargets();
setInterval(getDataAndUpdateView, 2000);
getDataAndUpdateView();

function addSourcesAndTargets() {
    $.get("sourcesandtargets", function (data) {
        var obj = jQuery.parseJSON(data);
        addOptions(document.getElementById("sourceOptions"), obj.sources);
        addOptions(document.getElementById("targetOptions"), obj.targets);
    });
}

function addOptions(element, options) {
    for (var i = 0; i < options.length; i++) {
        var entry = document.createElement("li");
        entry.innerText = options[i];
        entry.setAttribute("onclick","selectOption(this)")
        element.appendChild(entry);
    }
}

function getDataAndUpdateView() {
    updateConnectionStatus();
    if (currentView == "current") {
        getDataAndUpdateTable("currentorders", "currentOrdersList", true);
    }
    if (currentView == "history")
        getDataAndUpdateTable("orderhistory", "orderHistoryList");
}

function updateConnectionStatus() {
    $.get("connectionstatus", function (data) {
        var obj = jQuery.parseJSON(data);
        document.getElementById("connectionPLC").src = (obj.PLC) ? 'images/connectionOn.svg' : 'images/connectionOff.svg';
        document.getElementById("connectionFleetManager").src = (obj.FleetManager) ? 'images/connectionOn.svg' : 'images/connectionOff.svg';
        document.getElementById("connectionMFC").src = 'images/connectionOn.svg';
    }).fail(function (jqXHR, textStatus, errorThrown) {
        document.getElementById("connectionMFC").className = "connectionNotOk";
    });
}

function getDataAndUpdateTable(url, tableId, deleteButtons = false) {
    $.get(url, function (data) {
        var obj = jQuery.parseJSON(data);
        var tbody = document.getElementById(tableId).getElementsByTagName("tbody")[0];
        //update table content
        deleteTableRows(tbody);
        for (var i = 0; i < obj.data.length; i++) {
            var row = addRowToTable(obj.data[i], deleteButtons);
            tbody.insertAdjacentElement("beforeend", row);
            if (deleteButtons) {
                if (!obj.data[i][obj.data[i].length - 1])
                {
                    row.lastChild.innerHTML = '<button class=\"button-secondary button-small\" type=\"button\" onclick=\"deleteOrder(' + obj.data[i][0].toString() + ')\"><img src="images/delete.svg"></button>';
                    row.lastChild.className += ' icon'
                }
                else
                    row.lastChild.innerHTML = "requested";
            }
        }
    });
}

function deleteTableRows(tbody) {
    while (tbody.children.length > 0)
        tbody.children[0].remove();
}

function addRowToTable(data) {
    var tr = document.createElement("tr");
    //Work Station
    Object.keys(dataIndexes).forEach(function(key) {
        var td = document.createElement("td");
            if(data[dataIndexes[key]] === undefined)
                td.InnerText = "";
            else
                td.innerText = data[dataIndexes[key]];
        tr.appendChild(td);
    })
    return tr;
}

function changeTab(event, content) {
    if (content == "current") {
        $("#currentTab").addClass("active");
        $("#historyTab").removeClass("active");
        $("#currentOrders").addClass("active");
        $("#orderHistory").removeClass("active");
        $("#currentOrdersButtons").addClass("active")
        $("#orderHistoryButtons").removeClass("active")
        currentView = "current";
    }
    else {
        $("#currentTab").removeClass("active");
        $("#historyTab").addClass("active");
        $("#currentOrders").removeClass("active");
        $("#orderHistory").addClass("active");
        $("#currentOrdersButtons").removeClass("active")
        $("#orderHistoryButtons").addClass("active")
        currentView = "history";
    }
    getDataAndUpdateView();
}

function addManualOrder(event) {
    var source = document.getElementById("sourceSelection").value;
    var target = document.getElementById("targetSelection").value;

    var data = "{ \"source\": \"" + source + "\", \"target\": \"" + target + "\" }";
    formClose();
    $.post("addmanualorder", data)
        .fail(function () {
            alert("Failed to add manual order!");
        });
}

function deleteOrder(orderId) {
    dialogOn(orderId)
}

function dialogOn(orderId) {
    if(orderId === undefined)
        orderId = "" //for handling manual orders without ID
    document.getElementById("screen-skinner").style.display = "block";
    document.getElementsByClassName("message")[0].innerHTML ='<img src="images/warning_black.svg"/> Do you really want to delete order ' + orderId.toString() +"?"
    document.getElementsByClassName("message")[0].id = orderId
  }
  function scrollTable(direction, element) {
    var tableContainer = document.getElementById(element);
    var scrollStep = 100;
    
    if (direction === 'up') {
      tableContainer.scrollTop -= scrollStep;
    } else if (direction === 'down') {
      tableContainer.scrollTop += scrollStep;
    }
  }
  function deleteOrderDialog()
  {
    var orderId = document.getElementsByClassName("message")[0].id
    var data = "{ \"orderId\": \"" + orderId + "\" }";
    off();
    $.post("deleteorder", data)
        .fail(function () {
            alert("Failed to delete order!");
        });
  }
  function off() {
    document.getElementById("screen-skinner").style.display = "none";
  }

  function openForm()
  {
    document.getElementById('form-skinner').style.display = "block";
  }
  function formClose()
  {
    document.getElementById('form-skinner').style.display = "none";
  }

  function toggleOptions(caller) {
    var options = document.querySelector('#'+caller.id+'Options');
    options.style.display = options.style.display === 'none' ? 'block' : 'none';
  }
  //Hide Options of select when pressed outside of select div
  document.addEventListener('click', function(event) {
    var customSelect = document.querySelector('.custom-select');
    if (event.target !== customSelect && !customSelect.contains(event.target)) {
    var options = customSelect.querySelector('.options');
    options.style.display = 'none';
}
});
function selectOption(option) {
    var caller = option.parentElement.parentElement;
    var value = option.textContent;
    document.querySelector('#'+caller.id+'Selection').value = value;
    document.querySelector('.options').style.display = 'hidden';
}